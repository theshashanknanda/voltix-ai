def main():
    print("hello")
